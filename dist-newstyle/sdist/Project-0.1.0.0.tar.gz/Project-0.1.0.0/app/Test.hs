module Test where

{-# LANGUAGE PackageImports #-}

import "haskeline" System.Console.Haskeline
import qualified "haskeline" System.Console.Haskeline.Key as Key

main :: IO ()
main = do
  input <- runInputT defaultSettings getInput
  putStrLn $ "You pressed: " ++ show input

getInput :: InputT IO Key.Key
getInput = do
  event <- getInputEvent ""
  case event of
    Just (Key.KeyInput key) -> return key
    _                       -> getInput