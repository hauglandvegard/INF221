module Main where

{-import qualified Game.Gameloop as G

main :: IO ()
main = G.startGame
-}

import Test

main :: IO()
main = Test.test